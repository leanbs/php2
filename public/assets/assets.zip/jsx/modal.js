$(document).ready(function() {
    // 
});
